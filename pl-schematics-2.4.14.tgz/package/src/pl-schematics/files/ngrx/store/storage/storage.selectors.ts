import { createFeatureSelector, createSelector } from '@ngrx/store';
import { storageFeatureKey } from './storage.reducer';
import { StorageState } from './storage.state';

export const selectStorageState =
  createFeatureSelector<StorageState>(storageFeatureKey);

export const selectStorageToken = createSelector(
  selectStorageState,
  function(state: StorageState): string | null {
    return state.token;
  },
);

export const selectStorageLanguage = createSelector(
  selectStorageState,
  function(state: StorageState): string {
    return state.language;
  },
);

export const selectStorageTheme = createSelector(
  selectStorageState,
  function(state: StorageState): 'light' | 'dark' {
    return state.theme;
  },
);