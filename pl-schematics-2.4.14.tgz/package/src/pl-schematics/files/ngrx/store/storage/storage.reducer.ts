import { createReducer, on } from '@ngrx/store';
import {
  storageClear,
  storageHydrateSuccess,
  storageSetLanguage,
  storageSetTheme,
  storageSetToken,
} from './storage.actions';
import { initialStorageState, StorageState } from './storage.state';

export const storageFeatureKey = 'storage';

export const storageReducer = createReducer(
  initialStorageState,

  on(storageHydrateSuccess, function(state, action): StorageState {
    return {
      ...state,
      token: action.token,
      language: action.language,
      theme: action.theme,
    };
  }),

  on(storageSetToken, function(state, action): StorageState {
    return {
      ...state,
      token: action.token,
    };
  }),

  on(storageSetLanguage, function(state, action): StorageState {
    return {
      ...state,
      language: action.language,
    };
  }),

  on(storageSetTheme, function(state, action): StorageState {
    return {
      ...state,
      theme: action.theme,
    };
  }),

  on(storageClear, function(): StorageState {
    return initialStorageState;
  }),
);