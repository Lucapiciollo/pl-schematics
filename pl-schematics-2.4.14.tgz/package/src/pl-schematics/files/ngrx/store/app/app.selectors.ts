import { createFeatureSelector, createSelector } from '@ngrx/store';
import { appFeatureKey } from './app.reducer';
import { AppState } from './app.state';

export const selectAppState =
  createFeatureSelector<AppState>(appFeatureKey);

export const selectAppInitialized = createSelector(
  selectAppState,
  function(state: AppState): boolean {
    return state.initialized;
  },
);

export const selectAppLoading = createSelector(
  selectAppState,
  function(state: AppState): boolean {
    return state.loading;
  },
);

export const selectAppError = createSelector(
  selectAppState,
  function(state: AppState): string | null {
    return state.error;
  },
);