import { Rule } from "@angular-devkit/schematics";
export declare function check(obj: any): Rule;
