import { Rule } from '@angular-devkit/schematics';
import { PlSchematicsOptions } from '../types/schema-options';
export declare function addClass(options: PlSchematicsOptions, urlFile: string, destPath: string): Rule;
