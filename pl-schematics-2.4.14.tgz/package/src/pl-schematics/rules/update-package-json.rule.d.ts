import { Rule } from '@angular-devkit/schematics';
import { PlSchematicsOptions } from '../types/schema-options';
export declare function updatePackageJsonForSonar(): Rule;
export declare function updatePackageJsonForBuild(options: PlSchematicsOptions): Rule;
