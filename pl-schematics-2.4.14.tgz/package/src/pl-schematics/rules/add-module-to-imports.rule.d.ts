import { Rule } from '@angular-devkit/schematics';
import { PlSchematicsOptions } from '../types/schema-options';
export declare function addModuleToImports(options: PlSchematicsOptions, moduleName: string, libName: string): Rule;
