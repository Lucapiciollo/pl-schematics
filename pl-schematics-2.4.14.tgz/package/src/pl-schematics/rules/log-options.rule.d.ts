import { Rule } from '@angular-devkit/schematics';
import { PlSchematicsOptions } from '../types/schema-options';
export declare function logOptions(options: PlSchematicsOptions): Rule;
