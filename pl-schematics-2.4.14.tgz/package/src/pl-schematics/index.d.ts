import { Rule } from '@angular-devkit/schematics';
import { PlSchematicsOptions } from './types/schema-options';
export default function plSchematics(options: PlSchematicsOptions): Rule;
