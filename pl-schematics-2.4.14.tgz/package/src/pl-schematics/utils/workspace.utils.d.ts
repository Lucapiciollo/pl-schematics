import { Tree } from '@angular-devkit/schematics';
import { JsonObject } from './json.utils';
import { PlSchematicsOptions } from '../types/schema-options';
export declare function getDefaultProjectName(workspaceJson: JsonObject, options: PlSchematicsOptions): string;
export declare function getProjectObject(workspaceJson: JsonObject, options: PlSchematicsOptions): JsonObject;
export declare function getProjectDefaultPath(host: Tree, options: PlSchematicsOptions): string | null;
