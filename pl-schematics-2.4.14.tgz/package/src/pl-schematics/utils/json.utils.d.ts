import { Tree } from '@angular-devkit/schematics';
export declare type JsonObject = Record<string, any>;
export declare function readJsonFile<T extends JsonObject = JsonObject>(host: Tree, path: string): T | null;
export declare function overwriteJsonFile(host: Tree, path: string, json: JsonObject): void;
export declare function ensureArray<T>(value: T[] | undefined): T[];
export declare function pushIfMissing<T>(array: T[], value: T): void;
